window.onload = function () {
    var button_ = $('#button_');
    button_.click( function () {//给对象绑定事件
        console.log('click');
        chrome.tabs.getSelected(null, function (tab) {//获取当前tab
            //向tab发送请求
            chrome.tabs.sendRequest(tab.id, { action: "GetBaiduKeyWord" }, function (response) {
            });
        });
    });
};