'use strict';
function run() {
    chrome.extension.onRequest.addListener(//监听扩展程序进程或内容脚本发送的请求
        function (request, sender, sendResponse) {
            if (request.action == "GetBaiduKeyWord") {
                $('#kw').val('abcdd');
                $('#result_logo').remove();
            }
        }
    );
}
run();